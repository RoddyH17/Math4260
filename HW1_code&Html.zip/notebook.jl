### A Pluto.jl notebook ###
# v0.20.4

using Markdown
using InteractiveUtils

# ╔═╡ 7108b99c-357b-4385-8b6e-07d7e757d543
using LinearAlgebra

# ╔═╡ 2e4de51a-6342-4210-b10a-6a377c1e4cbf
using BenchmarkTools

# ╔═╡ 66e0c438-7737-4ed2-be6c-57e04b7d7dca
using Plots

# ╔═╡ e51b3be2-e244-11ef-3a7f-11713917530c
md"""
# HW1

This is a self-contained set of logical proof, reasoning,  
and code implementation for HW1. 

Finished at February 3, 2025.\
Author: Roddy Huang

"""


# ╔═╡ ba1ce01d-4635-49f7-8a52-5a3a13371df0
md" 
---
### Problem 1 a)

"

# ╔═╡ 2caca4c0-7cbc-47cf-9de9-d2bb2bcb1026
md"""
Before we do any matrix computational optimization, assume we calculate the trace of $D + uv^T$ directly. So we have to form the entire $n × n$ matrix $M = D + uv^T$ and then compute its trace by summing its diagonal. Forming the outer product $uv^T$ takes us $O(n^2)$ operations.

"""




# ╔═╡ 1a5a65cd-be68-4a4b-9f62-370ff6e944cb
md"""
Next, we want to make some optimizations. Because the trace of the diagonal matrix is simply the sum of its diagonal entries, which requires us to add $n$ numbers, it takes $O(n)$ operations. we then have, 

$$Tr(D)=\sum^n_{i=1}D_{ii}$$

and by expanding the second term, this requires us to do $n$ multiplications and $n-1$ additions, whichi is also $O(n)$ operations

$$Tr(uv^T) = \sum^n_{i=1}u_i v_i = u^T v$$

Combine, we can rewrite the trace of $D + uv^T$ as, 

$$\text{Tr}(D + uv^T) = \sum^n_{i=1}D_{ii} + u^T v$$

Since these two parts are performed sequentially, the overall complexity is then, 

$$O(n) + O(n) = O(n)$$

We can run a simulation to test it. 

"""


# ╔═╡ 54efc026-9d48-46cf-857b-4b568f7b2351
# Direct Method: 
function trace_direct(D::AbstractMatrix, u::AbstractVector, v::AbstractVector)
    n = size(D, 1)
    @assert n == size(D, 2) "D must be a square matrix"
    @assert length(u) == n && length(v) == n "length of u and v must equal to n"
    
    M = D + u * v'  # O(n^2)
    return sum(diag(M))  
end

# ╔═╡ f0521e5d-5562-4ea7-95ff-d95a881a4674
# Optimized Method:
function trace_optimized(D::AbstractMatrix, u::AbstractVector, v::AbstractVector)
    n = size(D, 1)
    @assert n == size(D, 2) 
    @assert length(u) == n && length(v) == n 
    
    trace_D = sum(diag(D))   # O(n)
    trace_uv = dot(u, v)       # O(n)
    return trace_D + trace_uv
end

# ╔═╡ fd1e3751-fa08-474d-8e0a-8e3e8b6156d4
# Testing and Timing
function benchmark_methods()
    n_values = [100, 500, 1000, 2000, 5000]
    times_direct = Float64[]
    times_optimized = Float64[]
    
    for n in n_values
        D = Diagonal(rand(n)) |> Matrix 
        u = rand(n)
        v = rand(n)
        
        # Timing 
        t_direct = @belapsed trace_direct($D, $u, $v)
        t_opt = @belapsed trace_optimized($D, $u, $v)
        
        push!(times_direct, t_direct)
        push!(times_optimized, t_opt)
        
        println("n = $n: Direct = $(t_direct*1e6) μs, Optimized = $(t_opt*1e6) μs")
    end
    
    # Plot the timing
    plot(n_values, times_direct .* 1e6, 
             xscale = :log10, yscale = :log10, 
             marker = :o, label = "Direct Method",
             xlabel = "Size", 
             ylabel = "Run Time",
             title = "Direct vs Optimized Trace ")
	plot!(n_values, times_optimized .* 1e6,
	         marker = :square, label = "Optimized Method",)
end

# ╔═╡ 6c26a87b-5fe3-4d77-aa11-8e2e99602134
benchmark_methods()

# ╔═╡ c8ac41bc-d3b5-48ce-827f-62343d60cc89
md" 
---
### Problem 1 b)

"

# ╔═╡ 5d36fbbb-355d-4715-b73b-589cb7d3e8c9
md"""
Assume we calculate $uv^T A$ directly, remember that $A \in \mathcal{R}^{n \times n}$. So we have to generate a $n \times n$ matrix by calculating the outer product, which has the complexity $O(n^2)$, and then use this $n \times n$ matrix to multiply with the matrix $A$, which is a standard Matrix $\times$ Matrix complexity, i.e. $O(n^3)$. So the overall complexity for the direct method is $O(n^3)$

"""

# ╔═╡ aec2b89d-f9b4-412c-80b4-88f298c67da7
md"""
However, by the associativity, we can do right-multiplication instead of left. We first calculate $v^T A$ to get another Vector , which is the standard Vector $\times$ Matrix complexity, i.e. $O(n^2)$. Next we calculate $u \times (v^T A)$, which is the standard Vector $\times$ Vector complexity, i.e. $O(n^2)$. So the overall complexity for the direct method is $O(n^3)$.

We can check this difference by some simulations.

"""

# ╔═╡ 2a88f6b2-efd6-4d86-8962-0e07e237b2cf
# Direct Method:
function direct_method(u::AbstractVector, v::AbstractVector, A::AbstractMatrix)
    M = u * v'       
    return M * A     
end

# ╔═╡ f3381fe1-78fe-4bdc-b769-5e457eba1381
# Optimized Method:
function optimized_method(u::AbstractVector, v::AbstractVector, A::AbstractMatrix)
    T = v' * A       
    return u * T     
end

# ╔═╡ 4c3b7291-40fe-41ba-9a95-eb8bba90f15f
md" 
---
### Problem 1 c)

"

# ╔═╡ 55a4c483-c491-4df0-81d1-c237312a434b
md"""
Assume we calculate $(I + uu^T)$ directly first and then we multiply the result with the vector $v$. To do the first step, we have to construct an outer product and add with the Identity matrix, with a complexity $O(n^2) + O(1)$, and the second step is a standard Matrix $\times$ Vector multiplicatio with a complexity $O(n^2)$.So the overall complexity for the direct method is $O(n^2)$.



"""

# ╔═╡ 9b37f0c6-d7f6-4b13-919e-3aedf9d6b727
md"""
So we want to avoid the construction of the outer product. By the distributive property of Matrix-Vector multiplication, we have 

$$(I + uu^T)v=Iv+(u^Tu)v$$

Then by the associativity, we have

$$Iv+(u^Tu)v = v + (u^Tv)u$$

so the computation of $(u^Tv)$ requires a complexity of $O(n)$, and the overall calculation $v + (u^Tv)u$ also has a $O(n)$ complexity, which is significantly lower than the direct method. 
We go to some simulation to compare. 


"""

# ╔═╡ 47b2bfc5-cee6-4fdc-9f46-955f734c13e4
# Direct Method
function direct_method(u::AbstractVector, v::AbstractVector)
    n = length(u)
    I_n = Matrix{Float64}(I, n, n)
    return (I_n + u * u') * v
end

# ╔═╡ 1e20168d-00df-4755-aec4-a3fe7cf542aa
# Optimized Method
function optimized_method(u::AbstractVector, v::AbstractVector)
    return v + (dot(u, v)) * u
end

# ╔═╡ f6e284b0-7a6a-4c63-a4b6-64ccec25bd48
md" 
---
### Problem 1 d)

"

# ╔═╡ 990bc37c-211f-4752-ae60-90af4ea5e17b
md"""
Assume we calculate $v^T AB u$ directly, from which we have a standard matrix multiplication A $\times B$ that requires a $O(n^3)$ complexity----that is already big!
By the associativity of Matrix Multiplication, we have 

$$v^T AB u = v^T (A(Bu))$$

So we seperate one operation of Matrix $\times$ Matrix to two Matrix $\times$ Vector operations: for $(Bu)$ 's complexity and $A(B(u))$'s are both complexity of $O(n^2)$, and the last operation is the dot product, which has only an $O(n)$ complexity. 

"""

# ╔═╡ 252f8891-29e0-4f81-824f-2f980db51199
# Direct Method
function direct_method(v::AbstractVector, A::AbstractMatrix, B::AbstractMatrix, u::AbstractVector)
    C = A * B         
    return dot(v, C * u)
end

# ╔═╡ 7f37d06d-48f1-4d13-8aaa-2d3139a8ec71
# Optimized Method
function optimized_method(v::AbstractVector, A::AbstractMatrix, B::AbstractMatrix, u::AbstractVector)
    tmp = B * u         
    tmp2 = A * tmp      
    return dot(v, tmp2)
end

# ╔═╡ 9ac536fb-67aa-4e8d-99f5-f9541a0e7cfe
#Testing and Timing
function benchmark_methods2()
    n_values = [100, 500, 1000, 2000]
    times_direct = Float64[]
    times_optimized = Float64[]

    for n in n_values
        u = rand(n)
        v = rand(n)
        A = rand(n, n)

        # Timing
        t_direct = @belapsed direct_method($u, $v, $A)
        t_opt = @belapsed optimized_method($u, $v, $A)

        push!(times_direct, t_direct)
        push!(times_optimized, t_opt)
        println("n = $n: Direct = $(t_direct*1e6) μs, Optimized = $(t_opt*1e6) μs")
    end

    # Plot the timing
    plot(n_values, times_direct .* 1e6, 
             xscale = :log10, yscale = :log10, 
             marker = :o, label = "Direct Method",
             xlabel = "Size", 
             ylabel = "Run Time",
             title = "Direct vs Optimized Trace ")
	plot!(n_values, times_optimized .* 1e6,
	         marker = :square, label = "Optimized Method",)
end

# ╔═╡ ea7096ae-e6fe-4438-bd87-b974bb26a94d
benchmark_methods2()

# ╔═╡ b8a9a54c-1a00-4793-a27e-e903663a2fa5
#Testing and Timing
function benchmark_methods3()
    n_values = [100, 500, 1000, 2000]
    times_direct = Float64[]
    times_optimized = Float64[]

    for n in n_values
        u = rand(n)
        v = rand(n)

        t_direct = @belapsed direct_method($u, $v)
        t_opt = @belapsed optimized_method($u, $v)
        
        push!(times_direct, t_direct)
        push!(times_optimized, t_opt)
        println("n = $n: Direct = $(t_direct*1e6) μs, Optimized = $(t_opt*1e6) μs")
    end

    # Plot the timing
    plot(n_values, times_direct .* 1e6, 
             xscale = :log10, yscale = :log10, 
             marker = :o, label = "Direct Method",
             xlabel = "Size", 
             ylabel = "Run Time",
             title = "Direct vs Optimized Trace ")
	plot!(n_values, times_optimized .* 1e6,
	         marker = :square, label = "Optimized Method",)
end

# ╔═╡ a4862f08-62d2-4d34-b7e1-71f8cc01e50c
benchmark_methods3()

# ╔═╡ c21f610d-63e3-4ba2-b099-1b7552e57a0c
#Testing and Timing
function benchmark_methods4()
    n_values = [100, 500, 1000, 2000]
    times_direct = Float64[]
    times_optimized = Float64[]

    for n in n_values
        A = rand(n, n)
        B = rand(n, n)
        u = rand(n)
        v = rand(n)
        
        t_direct = @belapsed direct_method($v, $A, $B, $u)
        t_opt = @belapsed optimized_method($v, $A, $B, $u)
        
        push!(times_direct, t_direct)
        push!(times_optimized, t_opt)
        println("n = $n: Direct = $(t_direct * 1e6) μs, Optimized = $(t_opt * 1e6) μs")
    end

	# Plot the timing
    plot(n_values, times_direct .* 1e6, 
             xscale = :log10, yscale = :log10, 
             marker = :o, label = "Direct Method",
             xlabel = "Size", 
             ylabel = "Run Time",
             title = "Direct vs Optimized Trace ")
	plot!(n_values, times_optimized .* 1e6,
	         marker = :square, label = "Optimized Method",)
end


# ╔═╡ 48376322-4d91-4640-b555-1951b716184d
benchmark_methods4()

# ╔═╡ 22cc6ae1-1bc0-48ce-8353-b955b6beb737
md" 
---
### Problem 1 e,f,g): Comparing different Methods to Compute Matrix-Matrix Multiply

"

# ╔═╡ 3185d2c0-7150-4a6d-aa23-b56174fb6cd3
md"""
This part I write the code referred to the 2023Fall term's [notebook](https://www.cs.cornell.edu/courses/cs4220/2023sp/lec/2023-01-23.html), under the topic "Matrix --- Matrix Multiply", where professor Bindel shows the same story(which is the correct answer for what the prompt asks us to do).
"""

# ╔═╡ 819dd2e0-6170-402c-9bec-58d2f0c74799
md"""
So the difference between the three types of Matrix-Matrix Computataion method is clear: e) uses three nested loops and only scalar multiplications to compute; f) computes each column of $C$ using the build-in matrix-vector multiplication that can reduced the complexity comparing with e); and g) uses Julia's $A*B$, which calls a BLAS routine that is optimized at a low level for Matrix-Matrix Multiplication. 


"""

# ╔═╡ 1b5c73e0-db3e-4e8d-b27d-ac913cfe5711
# (e) Scalar multiplication using three nested loops
function matmul_scalar(A::AbstractMatrix, B::AbstractMatrix)
    m, nA = size(A)
    nB, p = size(B)
    @assert nA == nB "Inner dimensions must match."
    C = zeros(eltype(A), m, p)
    for i in 1:m
        for j in 1:p
            s = zero(eltype(A))
            for k in 1:nA
                s += A[i, k] * B[k, j]
            end
            C[i, j] = s
        end
    end
    return C
end

# ╔═╡ 3de20394-e842-4f1a-bac6-a97183ed45ac
# (f) Column-by-column multiplication using built-in matrix-vector products
function matmul_colbycol(A::AbstractMatrix, B::AbstractMatrix)
    m, nA = size(A)
    nB, p = size(B)
    @assert nA == nB "Inner dimensions must match."
    C = zeros(eltype(A), m, p)
    for j in 1:p
        C[:, j] = A * B[:, j]  
    end
    return C
end


# ╔═╡ 4b2cf9d2-dfab-4508-bc8f-a57aa584d76e
# (g) Built-in multiplication (direct BLAS call)
function matmul_builtin(A::AbstractMatrix, B::AbstractMatrix)
    return A * B
end

# ╔═╡ e8466e67-a177-46b6-979b-012a73d52eb1
# Benchmark all methods over a range of sizes
function benchmark_all()
    # Use relatively small sizes because the O(n^3) triple-loop method becomes slow for large n.
    ns = [20, 40, 60, 80, 100]
    times_scalar = Float64[]
    times_colbycol = Float64[]
    times_builtin = Float64[]
    
    for n in ns
        A = rand(n, n)
        B = rand(n, n)
        
        # Benchmark (e): scalar triple-loop
        t_scalar = @belapsed matmul_scalar($A, $B)
        push!(times_scalar, t_scalar)
        
        # Benchmark (f): column-by-column (matrix-vector multiplications)
        t_colbycol = @belapsed matmul_colbycol($A, $B)
        push!(times_colbycol, t_colbycol)
        
        # Benchmark (g): built-in multiplication
        t_builtin = @belapsed matmul_builtin($A, $B)
        push!(times_builtin, t_builtin)
        
        println("n = $n: Scalar = $(t_scalar * 1e6) μs, Col-by-col = $(t_colbycol * 1e6) μs, Built-in = $(t_builtin * 1e6) μs")
    end


	# Plot the timing
	plot(ns, times_scalar .* 1e6,
     marker = :circle, lw = 2, label = "Scalar (triple-loop)",
     xscale = :log10, yscale = :log10,
     xlabel = "Matrix size n",
     ylabel = "Run Time (μs)",
     title = "Matrix Multiplication: Performance Comparison")
    plot!(ns, times_colbycol .* 1e6,
      marker = :square, lw = 2, label = "Column-by-col (matvec)")
    plot!(ns, times_builtin .* 1e6,
      marker = :diamond, lw = 2, label = "Built-in (BLAS)")
end


# ╔═╡ 77e44a1c-34d9-44e8-97d8-8c744c147582
benchmark_all()

# ╔═╡ a0f23dd8-004f-46f9-a2cd-2aa665586635
md"""
Here's a possible interpretation for the graph:
1. The Scalar triple-loop method is the slowest due both to its Complexity and the overhead of interpreting nested loops in Julia
2. The column-by-column method is faster than the pure scalar method since it leverages the BLAS routines for matrix-vector multiplication.
3. The built-in multiplication is the fastest because it directly invokes the optimized BLAS routine for matrix–matrix multiplication, which has been tuned for the hardware.

"""

# ╔═╡ e9f28824-c13c-4aac-981d-061b4d5571b1
md" 
---
### Problem 2 a)

"

# ╔═╡ 57cecc82-11ee-4129-a93e-a0ca946ae561
md"""

#### Prove that $|| x ||_\infty ≤ || x ||_2 \leq \sqrt{n} || x ||_\infty$

##### Proof: 

Our first step is to prove that $|| x ||_\infty ≤ || x ||_2$


Recall the definition of Infinity Norm$(|| · ||_\infty)$:

$$|| x ||_\infty = max_{1\leq i \leq n} |x_i|$$


and the definition of the 2-Norm$(|| · ||_2)$:

$$|| x ||_2 = \sqrt{\sum^n_{i=1} x^2_i}$$

We let $M = || x ||_\infty$. Then by definition of $|| x ||_\infty$, we have for every component of $|x_i| \leq M$

If we take a square of 2-Norm on both side we have

$$|| x ||^2_2 = \sum^n_{i=1} x^2_i$$

Obviously, we have 

$$\sum^n_{i=1} x^2_i \geq x_i^2$$

Since there is at least one index $j$ such that $|x_j| = M$

$$|| x ||^2_2 = \sum^n_{i=1} x^2_i \geq x_j^2 = M^2$$

Taking the square root on both sides we have

$$|| x ||_2 \geq M = || x ||_\infty$$

which completes our first proof. 

Our next step is to prove $|| x ||_2 \leq \sqrt{n} || x ||_\infty$

So for all $i$, we have $x_i^2 \leq M^2$. Then we can sum these inequality for i = 1,2,...,n and get, 

$$\sum^n_i x^2_i \leq \sum^n_i M^2 = n M^2$$

It's obvious right now to see that when we take the square root of both sides:

$$|| x ||_2 = \sqrt{\sum^n_{i=1} x^2_i} \leq \sqrt{n M^2} = \sqrt{n} M = \sqrt{n}  || x ||_\infty$$

So we prove that $|| x ||_\infty ≤ || x ||_2$. Combining both steps, we have 

$|| x ||_\infty ≤ || x ||_2 \leq \sqrt{n} || x ||_\infty$





"""

# ╔═╡ 937ec45b-5416-47ec-91dc-1784f5d91b79
md" 
---
### Problem 2 b)

"

# ╔═╡ 9ebdca25-0f08-446b-8216-b7a7ea3b5a77
md"""

#### Prove that $|| A ||_2 \leq \sqrt{n} || A ||_\infty$

##### Proof: 
Recall that $|| A ||_2$ is the induced 2-norm defined by 

$$|| A ||_2 = \sup_{\substack{x ≠ 0}} \frac{|| Ax ||_2}{|| x ||_2} = \max_{\substack{|| x ||_2 =1}}|| Ax ||_2$$

Also  $|| A ||_\infty$ is the induced infinity-norm defined by 

$$|| A ||_\infty = \sup_{\substack{x ≠ 0}} \frac{|| Ax ||_\infty}{|| x ||_\infty} = \max_{\substack{|| x ||_\infty =1}}|| Ax ||_\infty = \max_{\substack{1\leq i \leq n} }\sum^n_{j=1} |A_{ij}|$$

Since from the part a), we know that for any given vector y $\in \mathcal{R}^n$, 

$|| y ||_\infty ≤ || y ||_2 \leq \sqrt{n} || y ||_\infty$


Consider the vector $y = Ax$. Using the above inequality, we can rewrite:

$|| Ax ||_\infty ≤ || x ||_2 \leq \sqrt{n} || Ax ||_\infty$

and particularly, we have the triangular inequality that shows

$||Ax||_\infty = \max_{\substack{|| x ||_\infty =1}}|| Ax ||_\infty \leq \max_{\substack{|| x ||_\infty =1}}|| A ||_\infty || x ||_\infty$

So, for any such $x$ with $|| x ||_2 =1$, we also have

$|| x ||_\infty \leq || x ||_2 =1$

Therefore combining the two inequalities;

$|| Ax ||_\infty \leq \sqrt{n} || Ax ||_\infty \leq \sqrt{n}|| A ||_\infty || x ||_\infty = \sqrt{n}|| A ||_\infty$

Since the above holds for every $x$ with $|| x ||_2 =1$ and taking the maximum over such $x$ gives:

$|| A ||_2 =  \max_{\substack{|| x ||_2 =1}} || Ax ||_2 \leq \sqrt{n}|| A ||_\infty$

"""

# ╔═╡ 6ba1816b-4721-4ed5-8ebd-bd3266117309
md" 
---
### Problem 2 c)

"

# ╔═╡ a301ee78-cef0-4b7b-87cf-6df6ee4d2b10
md"""

#### Prove that For any orthogonal matrix $Q \in R^{n\times n}: || Qx ||_2 = || x ||_2$

##### Proof: 

By definition, the 2-norm of vector $y$ is given by $|| y ||_2 = \sqrt{y^T y}$ \
Then we let $y = Qx$, we have 

$|| Qx ||_2 = \sqrt{(Qx)^T (Qx)}$

Notice that we have 

$(Qx)^T = x^T Q^T$

So we can rewrite, 

$|| Qx ||_2 = \sqrt{x^T Q^T Q x}$

Given that $Q$ is an $n \times n$ orthogonal matrix and so $Q^T Q = I$, hence: 


$|| Qx ||_2 = \sqrt{x^T (Q^T Q)x} = \sqrt{x^T I x} = \sqrt{x^T x}$

By definition, this is exactly the form of the 2-norm for $x$. 

Therefore,  $|| Qx ||_2 = || x ||_2$




"""

# ╔═╡ 2bc4374d-0da1-4c90-9e1c-d2fdcbe35b4d
md" 
---
### Problem 2 d)

"

# ╔═╡ c175e2d1-84c7-41a5-be24-6deb59da761f
md"""


#### Prove that $|| A ||_2 = \sigma_{max}$, where $σ_{max}$ is the largest singular value of A

##### Proof: 

So we want to prove 

$$|| A ||_2 = \sup_{\substack{x ≠ 0}} \frac{|| Ax ||_2}{|| x ||_2} = \max_{\substack{|| x ||_2 =1}}|| Ax ||_2 = \sigma_{max}$$

We can recall the process of Singular Value Decomposition.

Recall that any $m \times n$ matrix A can be written in the form 

$A = U \Sigma V^T$

where $U$ is an $m \times m$ orthogonal matrix, $V$ is an $n \times n$ orthogonal matrix, and $\Sigma$ is an $m \times n$ diagonal matrix with non-negative entries $\sigma_1 \geq \sigma_2 \geq ... \geq 0$ on the diagonal. These entires are called the singular values of $A$. 

So our first step is to express $|| Ax ||_2$ via the SVD. 

For any vector $x \in R^n$ with $|| x ||_2 =1, define 

$y = V^T x$

Since $V$ is orthogonal, $y$ is also a unit vector, then we have

$Ax = U \Sigma V^T x = U \Sigma y$

By the fact that $U$ is orthogonal, it preserves the 2-norm. Thus, 

$|| Ax ||_2 = || U \Sigma y||_2 = || \Sigma y||_2$

So 

$(\Sigma y)_i = \sigma_i y_i, for \ i = 1, ... , min(m,n)$

Thus we have 

$|| \Sigma y ||_2 = \sqrt{ \sum_i \sigma^2_i y^2_i}$

Since $y$ is any unit vector(i.e. $\sum_i y^2_i = 1$), the maximum value of $\sqrt{ \sum_i \sigma^2_i y^2_i}$ is attained when all the weight is placed on the largest singular value $\sigma_1 = \sigma_{max}$ (which is also called the principal singular anlaysis that contains the largest information). So if we choose 

$y = [1,0,0,...]^T$

then 

$|| \Sigma y ||_2 = \sqrt{\sigma^2_1 · 1 + \Sigma_{i \geq 2}\sigma^2_i ·0} = \sigma_1$ 

For any other unit vector $y$, by the Cauchy-Schwarz Inequality, 

$|\sum^n_{i=1} u_i v_i| \leq \sqrt{\sum^n_{i=1} u^2_i} \sqrt{\sum^n_{i=1} v^2_i}$


we therefore derive that 

$|| Ax ||_2 = || \Sigma y||_2 \leq \sigma_{max}$

So for all $x$ with $|| x ||_2 =1$, and there exists a unit vecotr $x$ for which the equality is achieved, then we have 

$$|| A ||_2 = \sup_{\substack{x ≠ 0}} \frac{|| Ax ||_2}{|| x ||_2} = \max_{\substack{|| x ||_2 =1}}|| Ax ||_2 = \sigma_{max}$$

"""

# ╔═╡ 139ae075-2a24-4051-a533-929b44796931
md" 
---
### Problem 2 e)

"

# ╔═╡ 57420368-0a8b-49ee-b9c6-2c27073ea047
md"""


#### Prove that For any orthogonal matrix $Q \in R^{n \times n} : || QA ||_2 = || A ||_2$

##### Proof: 





"""

# ╔═╡ 3afc1086-5f53-4891-acd3-b2e039f9a7fc
md"""

So we start with the definition of the norm for $QA$:

$|| QA ||_2 = \sup_{\substack{|| x ||_2 =1}}|| QAx||_2$

We know that for the orthogonal matrix it preserves the 2-norm. Then for any vector $y \in R^n$, 

$|| Qy ||_2 = || y ||_2$

Since $(Ax)$ produces a product, so we have 

$|| QA ||_2 = || Ax||_2$

Therefore, we have 

$|| QA ||_2 = \sup_{\substack{|| x ||_2 =1}}|| Ax||_2 = || A ||_2$

"""

# ╔═╡ 2331344a-444f-4729-9e33-39381f3d65ef
md" 
---
### Problem 3

"

# ╔═╡ 7cfd3185-98ac-454f-8c6b-10a19f56a9b0
md"""

#### Let $V \in \mathcal{R}^{m \times n}$ with $m > n$ be a matrix with linearly independent columns, prove that 

a) $V^TV$ is positive definite \
b) $VV^T$ is positive semi-definite but not positive definite




##### Proof a): 

If a matrix $M$ is said to be positive definite for every nonzero vector $x \in \mathcal{R}^n$

we have

$x^T M x >0$

for part a), consider $M = V^TV$ and take any nonzero vector $x \in \mathcal{R}^n$,

$x^T (V^T V)x = (Vx)^T(Vx) = || Vx ||^2_2$

Given that the columns of $V$ are linearly independent, the only solution to $Vx=0$ is $x=0$. So for any nonzero x, we have $Vx \neq 0$ and hence 

$x^T (V^T V)x =|| Vx ||^2_2 >0, \forall x \neq 0$

which means that $V^T V$ is positive definite.



##### Proof b): 


If a matrix $N$ is said to be positive definite for every nonzero vector $y \in \mathcal{R}^m$

we have

$y^T M y \geq 0$

for part b), consider $N = V V^T$ and take any nonzero vector $y \in \mathcal{R}^m$,

$y^T (V V^T)y = (V^T y)^T(V^T y) = || V^T y ||^2_2$

The positive property has been proved in a), we need to show that there exits a nonzero vector $y \in \mathcal{R}^m$ such that 

$y^T (V V^T)y =0$

Since $V$ is an $m \times n$ matrix iwth $m > n$ and its columns are linearly independent, the rank of $V$ is n. This implies that the rank of $V V^T$  is also n (the form of outer product). However,  $V V^T$ is an $m \times m$ matrix. Because m>n, the matrix $V V^T$ cannot be full rank and hence must have a nontrivial nullspace, which means that there exists a nonzero vector $y \in \mathcal{R}^m$ such that 

$(V V^T)y =0$

For this nonzero vector $y$, we have 

$y^T (V V^T)y =0$

This shows that $V V^T$ is not positive definite. So it is positive semidefinite.
"""

# ╔═╡ 15878f2a-5052-47ee-af26-eaf6af363ced
md" 
---
### Problem 4

"

# ╔═╡ 3cec9551-ae98-426d-9736-1229bf2a751b
md"""

#### For differentiable functions $f(x)$, where the input $x$ may be a vector $x =(x_1,x_2,...,x_n)$, we define the relative condition number $\kappa_2 (x)$ of computing $f(x)$ at $x$ as 

$\kappa_2 (x) \equiv \frac{ || J(x) ||_2}{ || f(x) ||_2 / || x ||_2 }$
\
a) Compute $\kappa_2(x)$ for subtraction, i.e. $f(x) = x_1 - x_2$. When is this an ill-conditioned problem?
\
a) Compute $\kappa_2(x)$ for multilication, i.e. $f(x) = x_1 x_2$. When is this an ill-conditioned problem?



##### Proof a): 

Let $f(x) = x_1 - x_2, \quad \text{with } x = (x_1, x_2) \in \mathbb{R}^2.$

The Jacobian (or derivative) of $f$ is

$$J(x) = \begin{bmatrix} \frac{\partial}{\partial x_1}(x_1 - x_2) & \frac{\partial}{\partial x_2}(x_1 - x_2) \end{bmatrix} = \begin{bmatrix} 1 & -1 \end{bmatrix}$$

Thus, its induced 2--norm is

$$\|J(x)\|_2 = \sqrt{1^2 + (-1)^2} = \sqrt{2}$$

Since $f(x)$ is a scalar, we have

$$\|f(x)\|_2 = |x_1 - x_2|$$

Also, for $x = (x_1,x_2)$ the norm is

$$\|x\|_2 = \sqrt{x_1^2 + x_2^2}$$

Therefore, the relative condition number is
$\kappa_2(x) = \frac{\sqrt{2}}{|x_1 - x_2|/\sqrt{x_1^2 + x_2^2}}
= \sqrt{2}\,\frac{\sqrt{x_1^2+x_2^2}}{|x_1-x_2|}$

The problem becomes ill--conditioned when $|x_1 - x_2|$ is very small compared to $\sqrt{x_1^2+x_2^2}$; that is, when

$|x_1 - x_2| \ll \sqrt{x_1^2+x_2^2}$

In practical terms, if $x_1 \approx x_2$, cancellation occurs, and small relative errors in $x_1$ or $x_2$ can lead to large relative errors in $f(x)=x_1-x_2$.


##### Proof b): 

Let $$f(x) = x_1 \, x_2, \quad \text{with } x = (x_1, x_2) \in \mathbb{R}^2.$$

The Jacobian of $f$ is

$$J(x) = \begin{bmatrix} \frac{\partial}{\partial x_1}(x_1x_2) & \frac{\partial}{\partial x_2}(x_1x_2) \end{bmatrix} = \begin{bmatrix} x_2 & x_1 \end{bmatrix}$$

Its 2--norm is
$$\|J(x)\|_2 = \sqrt{x_2^2 + x_1^2} = \sqrt{x_1^2+x_2^2}$$

Since $f(x)$ is a scalar,$$\|f(x)\|_2 = |x_1x_2|$$

Also, $\|x\|_2 = \sqrt{x_1^2+x_2^2}$. Therefore, the relative condition number is

$$\kappa_2(x) = \frac{\sqrt{x_1^2+x_2^2}}{|x_1x_2|/\sqrt{x_1^2+x_2^2}}
= \frac{x_1^2+x_2^2}{|x_1 x_2|}.$$


The multiplication $x_1x_2$ becomes ill--conditioned when $|x_1x_2|$ is very small relative to $x_1^2+x_2^2$. This typically occurs if one (or both) of $x_1$ or $x_2$ is near zero. In such cases, small relative errors in the inputs can cause large relative errors in the product.




"""

# ╔═╡ 5890a0b9-46b1-43db-8b7c-c99d9b6125f1


# ╔═╡ 00000000-0000-0000-0000-000000000001
PLUTO_PROJECT_TOML_CONTENTS = """
[deps]
BenchmarkTools = "6e4b80f9-dd63-53aa-95a3-0cdb28fa8baf"
LinearAlgebra = "37e2e46d-f89d-539d-b4ee-838fcccc9c8e"
Plots = "91a5bcdd-55d7-5caf-9e0b-520d859cae80"

[compat]
BenchmarkTools = "~1.6.0"
Plots = "~1.25.12"
"""

# ╔═╡ 00000000-0000-0000-0000-000000000002
PLUTO_MANIFEST_TOML_CONTENTS = """
# This file is machine-generated - editing it directly is not advised

julia_version = "1.11.2"
manifest_format = "2.0"
project_hash = "b33b60fac09b21aaa74c28cbe94bbeddc705074d"

[[deps.ArgTools]]
uuid = "0dad84c5-d112-42e6-8d28-ef12dabb789f"
version = "1.1.2"

[[deps.Artifacts]]
uuid = "56f22d72-fd6d-98f1-02f0-08ddc0907c33"
version = "1.11.0"

[[deps.Base64]]
uuid = "2a0f44e3-6c83-55bd-87e4-b1978d98bd5f"
version = "1.11.0"

[[deps.BenchmarkTools]]
deps = ["Compat", "JSON", "Logging", "Printf", "Profile", "Statistics", "UUIDs"]
git-tree-sha1 = "e38fbc49a620f5d0b660d7f543db1009fe0f8336"
uuid = "6e4b80f9-dd63-53aa-95a3-0cdb28fa8baf"
version = "1.6.0"

[[deps.Bzip2_jll]]
deps = ["Artifacts", "JLLWrappers", "Libdl", "Pkg"]
git-tree-sha1 = "8873e196c2eb87962a2048b3b8e08946535864a1"
uuid = "6e34b625-4abd-537c-b88f-471c36dfa7a0"
version = "1.0.8+4"

[[deps.Cairo_jll]]
deps = ["Artifacts", "Bzip2_jll", "CompilerSupportLibraries_jll", "Fontconfig_jll", "FreeType2_jll", "Glib_jll", "JLLWrappers", "LZO_jll", "Libdl", "Pixman_jll", "Xorg_libXext_jll", "Xorg_libXrender_jll", "Zlib_jll", "libpng_jll"]
git-tree-sha1 = "009060c9a6168704143100f36ab08f06c2af4642"
uuid = "83423d85-b0ee-5818-9007-b63ccbeb887a"
version = "1.18.2+1"

[[deps.ColorSchemes]]
deps = ["ColorTypes", "ColorVectorSpace", "Colors", "FixedPointNumbers", "PrecompileTools", "Random"]
git-tree-sha1 = "26ec26c98ae1453c692efded2b17e15125a5bea1"
uuid = "35d6a980-a343-548e-a6ea-1d62b119f2f4"
version = "3.28.0"

[[deps.ColorTypes]]
deps = ["FixedPointNumbers", "Random"]
git-tree-sha1 = "c7acce7a7e1078a20a285211dd73cd3941a871d6"
uuid = "3da002f7-5984-5a60-b8a6-cbb66c0b333f"
version = "0.12.0"
weakdeps = ["StyledStrings"]

    [deps.ColorTypes.extensions]
    StyledStringsExt = "StyledStrings"

[[deps.ColorVectorSpace]]
deps = ["ColorTypes", "FixedPointNumbers", "LinearAlgebra", "Requires", "Statistics", "TensorCore"]
git-tree-sha1 = "8b3b6f87ce8f65a2b4f857528fd8d70086cd72b1"
uuid = "c3611d14-8923-5661-9e6a-0046d554d3a4"
version = "0.11.0"

    [deps.ColorVectorSpace.extensions]
    SpecialFunctionsExt = "SpecialFunctions"

    [deps.ColorVectorSpace.weakdeps]
    SpecialFunctions = "276daf66-3868-5448-9aa4-cd146d93841b"

[[deps.Colors]]
deps = ["ColorTypes", "FixedPointNumbers", "Reexport"]
git-tree-sha1 = "64e15186f0aa277e174aa81798f7eb8598e0157e"
uuid = "5ae59095-9a9b-59fe-a467-6f913c188581"
version = "0.13.0"

[[deps.Compat]]
deps = ["TOML", "UUIDs"]
git-tree-sha1 = "8ae8d32e09f0dcf42a36b90d4e17f5dd2e4c4215"
uuid = "34da2185-b29b-5c13-b0c7-acf172513d20"
version = "4.16.0"
weakdeps = ["Dates", "LinearAlgebra"]

    [deps.Compat.extensions]
    CompatLinearAlgebraExt = "LinearAlgebra"

[[deps.CompilerSupportLibraries_jll]]
deps = ["Artifacts", "Libdl"]
uuid = "e66e0078-7015-5450-92f7-15fbd957f2ae"
version = "1.1.1+0"

[[deps.ConstructionBase]]
git-tree-sha1 = "76219f1ed5771adbb096743bff43fb5fdd4c1157"
uuid = "187b0558-2788-49d3-abe0-74a17ed4e7c9"
version = "1.5.8"

    [deps.ConstructionBase.extensions]
    ConstructionBaseIntervalSetsExt = "IntervalSets"
    ConstructionBaseLinearAlgebraExt = "LinearAlgebra"
    ConstructionBaseStaticArraysExt = "StaticArrays"

    [deps.ConstructionBase.weakdeps]
    IntervalSets = "8197267c-284f-5f27-9208-e0e47529a953"
    LinearAlgebra = "37e2e46d-f89d-539d-b4ee-838fcccc9c8e"
    StaticArrays = "90137ffa-7385-5640-81b9-e52037218182"

[[deps.Contour]]
deps = ["StaticArrays"]
git-tree-sha1 = "9f02045d934dc030edad45944ea80dbd1f0ebea7"
uuid = "d38c429a-6771-53c6-b99e-75d170b6e991"
version = "0.5.7"

[[deps.DataAPI]]
git-tree-sha1 = "abe83f3a2f1b857aac70ef8b269080af17764bbe"
uuid = "9a962f9c-6df0-11e9-0e5d-c546b8b5ee8a"
version = "1.16.0"

[[deps.DataStructures]]
deps = ["Compat", "InteractiveUtils", "OrderedCollections"]
git-tree-sha1 = "1d0a14036acb104d9e89698bd408f63ab58cdc82"
uuid = "864edb3b-99cc-5e75-8d2d-829cb0a9cfe8"
version = "0.18.20"

[[deps.DataValueInterfaces]]
git-tree-sha1 = "bfc1187b79289637fa0ef6d4436ebdfe6905cbd6"
uuid = "e2d170a0-9d28-54be-80f0-106bbe20a464"
version = "1.0.0"

[[deps.Dates]]
deps = ["Printf"]
uuid = "ade2ca70-3891-5945-98fb-dc099432e06a"
version = "1.11.0"

[[deps.Dbus_jll]]
deps = ["Artifacts", "Expat_jll", "JLLWrappers", "Libdl"]
git-tree-sha1 = "fc173b380865f70627d7dd1190dc2fce6cc105af"
uuid = "ee1fde0b-3d02-5ea6-8484-8dfef6360eab"
version = "1.14.10+0"

[[deps.DelimitedFiles]]
deps = ["Mmap"]
git-tree-sha1 = "9e2f36d3c96a820c678f2f1f1782582fcf685bae"
uuid = "8bb1440f-4735-579b-a4ab-409b98df4dab"
version = "1.9.1"

[[deps.DocStringExtensions]]
deps = ["LibGit2"]
git-tree-sha1 = "2fb1e02f2b635d0845df5d7c167fec4dd739b00d"
uuid = "ffbed154-4ef7-542d-bbb7-c09d3a79fcae"
version = "0.9.3"

[[deps.Downloads]]
deps = ["ArgTools", "FileWatching", "LibCURL", "NetworkOptions"]
uuid = "f43a241f-c20a-4ad4-852c-f6b1247861c6"
version = "1.6.0"

[[deps.EarCut_jll]]
deps = ["Artifacts", "JLLWrappers", "Libdl", "Pkg"]
git-tree-sha1 = "e3290f2d49e661fbd94046d7e3726ffcb2d41053"
uuid = "5ae413db-bbd1-5e63-b57d-d24a61df00f5"
version = "2.2.4+0"

[[deps.EpollShim_jll]]
deps = ["Artifacts", "JLLWrappers", "Libdl"]
git-tree-sha1 = "8a4be429317c42cfae6a7fc03c31bad1970c310d"
uuid = "2702e6a9-849d-5ed8-8c21-79e8b8f9ee43"
version = "0.0.20230411+1"

[[deps.Expat_jll]]
deps = ["Artifacts", "JLLWrappers", "Libdl"]
git-tree-sha1 = "e51db81749b0777b2147fbe7b783ee79045b8e99"
uuid = "2e619515-83b5-522b-bb60-26c02a35a201"
version = "2.6.4+3"

[[deps.Extents]]
git-tree-sha1 = "063512a13dbe9c40d999c439268539aa552d1ae6"
uuid = "411431e0-e8b7-467b-b5e0-f676ba4f2910"
version = "0.1.5"

[[deps.FFMPEG]]
deps = ["FFMPEG_jll"]
git-tree-sha1 = "53ebe7511fa11d33bec688a9178fac4e49eeee00"
uuid = "c87230d0-a227-11e9-1b43-d7ebe4e7570a"
version = "0.4.2"

[[deps.FFMPEG_jll]]
deps = ["Artifacts", "Bzip2_jll", "FreeType2_jll", "FriBidi_jll", "JLLWrappers", "LAME_jll", "Libdl", "Ogg_jll", "OpenSSL_jll", "Opus_jll", "PCRE2_jll", "Pkg", "Zlib_jll", "libaom_jll", "libass_jll", "libfdk_aac_jll", "libvorbis_jll", "x264_jll", "x265_jll"]
git-tree-sha1 = "74faea50c1d007c85837327f6775bea60b5492dd"
uuid = "b22a6f82-2f65-5046-a5b2-351ab43fb4e5"
version = "4.4.2+2"

[[deps.FileWatching]]
uuid = "7b1f6079-737a-58dc-b8bc-7a2ca5c1b5ee"
version = "1.11.0"

[[deps.FixedPointNumbers]]
deps = ["Statistics"]
git-tree-sha1 = "05882d6995ae5c12bb5f36dd2ed3f61c98cbb172"
uuid = "53c48c17-4a7d-5ca2-90c5-79b7896eea93"
version = "0.8.5"

[[deps.Fontconfig_jll]]
deps = ["Artifacts", "Bzip2_jll", "Expat_jll", "FreeType2_jll", "JLLWrappers", "Libdl", "Libuuid_jll", "Zlib_jll"]
git-tree-sha1 = "21fac3c77d7b5a9fc03b0ec503aa1a6392c34d2b"
uuid = "a3f928ae-7b40-5064-980b-68af3947d34b"
version = "2.15.0+0"

[[deps.Formatting]]
deps = ["Logging", "Printf"]
git-tree-sha1 = "fb409abab2caf118986fc597ba84b50cbaf00b87"
uuid = "59287772-0a20-5a39-b81b-1366585eb4c0"
version = "0.4.3"

[[deps.FreeType2_jll]]
deps = ["Artifacts", "Bzip2_jll", "JLLWrappers", "Libdl", "Zlib_jll"]
git-tree-sha1 = "786e968a8d2fb167f2e4880baba62e0e26bd8e4e"
uuid = "d7e528f0-a631-5988-bf34-fe36492bcfd7"
version = "2.13.3+1"

[[deps.FriBidi_jll]]
deps = ["Artifacts", "JLLWrappers", "Libdl"]
git-tree-sha1 = "846f7026a9decf3679419122b49f8a1fdb48d2d5"
uuid = "559328eb-81f9-559d-9380-de523a88c83c"
version = "1.0.16+0"

[[deps.GLFW_jll]]
deps = ["Artifacts", "JLLWrappers", "Libdl", "Libglvnd_jll", "Xorg_libXcursor_jll", "Xorg_libXi_jll", "Xorg_libXinerama_jll", "Xorg_libXrandr_jll", "libdecor_jll", "xkbcommon_jll"]
git-tree-sha1 = "fcb0584ff34e25155876418979d4c8971243bb89"
uuid = "0656b61e-2033-5cc2-a64a-77c0f6c09b89"
version = "3.4.0+2"

[[deps.GR]]
deps = ["Base64", "DelimitedFiles", "GR_jll", "HTTP", "JSON", "Libdl", "LinearAlgebra", "Pkg", "Printf", "Random", "RelocatableFolders", "Serialization", "Sockets", "Test", "UUIDs"]
git-tree-sha1 = "c98aea696662d09e215ef7cda5296024a9646c75"
uuid = "28b8d3ca-fb5f-59d9-8090-bfdbd6d07a71"
version = "0.64.4"

[[deps.GR_jll]]
deps = ["Artifacts", "Bzip2_jll", "Cairo_jll", "FFMPEG_jll", "Fontconfig_jll", "GLFW_jll", "JLLWrappers", "JpegTurbo_jll", "Libdl", "Libtiff_jll", "Pixman_jll", "Pkg", "Qt5Base_jll", "Zlib_jll", "libpng_jll"]
git-tree-sha1 = "bc9f7725571ddb4ab2c4bc74fa397c1c5ad08943"
uuid = "d2c73de3-f751-5644-a686-071e5b155ba9"
version = "0.69.1+0"

[[deps.GeoFormatTypes]]
git-tree-sha1 = "8e233d5167e63d708d41f87597433f59a0f213fe"
uuid = "68eda718-8dee-11e9-39e7-89f7f65f511f"
version = "0.4.4"

[[deps.GeoInterface]]
deps = ["DataAPI", "Extents", "GeoFormatTypes"]
git-tree-sha1 = "294e99f19869d0b0cb71aef92f19d03649d028d5"
uuid = "cf35fbd7-0cd7-5166-be24-54bfbe79505f"
version = "1.4.1"

[[deps.GeometryBasics]]
deps = ["EarCut_jll", "Extents", "GeoInterface", "IterTools", "LinearAlgebra", "StaticArrays", "StructArrays", "Tables"]
git-tree-sha1 = "b62f2b2d76cee0d61a2ef2b3118cd2a3215d3134"
uuid = "5c1252a2-5f33-56bf-86c9-59e7332b4326"
version = "0.4.11"

[[deps.Gettext_jll]]
deps = ["Artifacts", "CompilerSupportLibraries_jll", "JLLWrappers", "Libdl", "Libiconv_jll", "Pkg", "XML2_jll"]
git-tree-sha1 = "9b02998aba7bf074d14de89f9d37ca24a1a0b046"
uuid = "78b55507-aeef-58d4-861c-77aaff3498b1"
version = "0.21.0+0"

[[deps.Glib_jll]]
deps = ["Artifacts", "Gettext_jll", "JLLWrappers", "Libdl", "Libffi_jll", "Libiconv_jll", "Libmount_jll", "PCRE2_jll", "Zlib_jll"]
git-tree-sha1 = "b0036b392358c80d2d2124746c2bf3d48d457938"
uuid = "7746bdde-850d-59dc-9ae8-88ece973131d"
version = "2.82.4+0"

[[deps.Graphite2_jll]]
deps = ["Artifacts", "JLLWrappers", "Libdl", "Pkg"]
git-tree-sha1 = "01979f9b37367603e2848ea225918a3b3861b606"
uuid = "3b182d85-2403-5c21-9c21-1e1f0cc25472"
version = "1.3.14+1"

[[deps.Grisu]]
git-tree-sha1 = "53bb909d1151e57e2484c3d1b53e19552b887fb2"
uuid = "42e2da0e-8278-4e71-bc24-59509adca0fe"
version = "1.0.2"

[[deps.HTTP]]
deps = ["Base64", "Dates", "IniFile", "Logging", "MbedTLS", "NetworkOptions", "Sockets", "URIs"]
git-tree-sha1 = "0fa77022fe4b511826b39c894c90daf5fce3334a"
uuid = "cd3eb016-35fb-5094-929b-558a96fad6f3"
version = "0.9.17"

[[deps.HarfBuzz_jll]]
deps = ["Artifacts", "Cairo_jll", "Fontconfig_jll", "FreeType2_jll", "Glib_jll", "Graphite2_jll", "JLLWrappers", "Libdl", "Libffi_jll"]
git-tree-sha1 = "55c53be97790242c29031e5cd45e8ac296dadda3"
uuid = "2e76f6c2-a576-52d4-95c1-20adfe4de566"
version = "8.5.0+0"

[[deps.IniFile]]
git-tree-sha1 = "f550e6e32074c939295eb5ea6de31849ac2c9625"
uuid = "83e8ac13-25f8-5344-8a64-a9f2b223428f"
version = "0.5.1"

[[deps.InteractiveUtils]]
deps = ["Markdown"]
uuid = "b77e0a4c-d291-57a0-90e8-8db25a27a240"
version = "1.11.0"

[[deps.IrrationalConstants]]
git-tree-sha1 = "e2222959fbc6c19554dc15174c81bf7bf3aa691c"
uuid = "92d709cd-6900-40b7-9082-c6be49f344b6"
version = "0.2.4"

[[deps.IterTools]]
git-tree-sha1 = "42d5f897009e7ff2cf88db414a389e5ed1bdd023"
uuid = "c8e1da08-722c-5040-9ed9-7db0dc04731e"
version = "1.10.0"

[[deps.IteratorInterfaceExtensions]]
git-tree-sha1 = "a3f24677c21f5bbe9d2a714f95dcd58337fb2856"
uuid = "82899510-4779-5014-852e-03e436cf321d"
version = "1.0.0"

[[deps.JLLWrappers]]
deps = ["Artifacts", "Preferences"]
git-tree-sha1 = "a007feb38b422fbdab534406aeca1b86823cb4d6"
uuid = "692b3bcd-3c85-4b1f-b108-f13ce0eb3210"
version = "1.7.0"

[[deps.JSON]]
deps = ["Dates", "Mmap", "Parsers", "Unicode"]
git-tree-sha1 = "31e996f0a15c7b280ba9f76636b3ff9e2ae58c9a"
uuid = "682c06a0-de6a-54ab-a142-c8b1cf79cde6"
version = "0.21.4"

[[deps.JpegTurbo_jll]]
deps = ["Artifacts", "JLLWrappers", "Libdl"]
git-tree-sha1 = "eac1206917768cb54957c65a615460d87b455fc1"
uuid = "aacddb02-875f-59d6-b918-886e6ef4fbf8"
version = "3.1.1+0"

[[deps.LAME_jll]]
deps = ["Artifacts", "JLLWrappers", "Libdl"]
git-tree-sha1 = "170b660facf5df5de098d866564877e119141cbd"
uuid = "c1c5ebd0-6772-5130-a774-d5fcae4a789d"
version = "3.100.2+0"

[[deps.LERC_jll]]
deps = ["Artifacts", "JLLWrappers", "Libdl", "Pkg"]
git-tree-sha1 = "bf36f528eec6634efc60d7ec062008f171071434"
uuid = "88015f11-f218-50d7-93a8-a6af411a945d"
version = "3.0.0+1"

[[deps.LLVMOpenMP_jll]]
deps = ["Artifacts", "JLLWrappers", "Libdl"]
git-tree-sha1 = "78211fb6cbc872f77cad3fc0b6cf647d923f4929"
uuid = "1d63c593-3942-5779-bab2-d838dc0a180e"
version = "18.1.7+0"

[[deps.LZO_jll]]
deps = ["Artifacts", "JLLWrappers", "Libdl"]
git-tree-sha1 = "1c602b1127f4751facb671441ca72715cc95938a"
uuid = "dd4b983a-f0e5-5f8d-a1b7-129d4a5fb1ac"
version = "2.10.3+0"

[[deps.LaTeXStrings]]
git-tree-sha1 = "dda21b8cbd6a6c40d9d02a73230f9d70fed6918c"
uuid = "b964fa9f-0449-5b57-a5c2-d3ea65f4040f"
version = "1.4.0"

[[deps.Latexify]]
deps = ["Formatting", "InteractiveUtils", "LaTeXStrings", "MacroTools", "Markdown", "OrderedCollections", "Printf", "Requires"]
git-tree-sha1 = "8c57307b5d9bb3be1ff2da469063628631d4d51e"
uuid = "23fbe1c1-3f47-55db-b15f-69d7ec21a316"
version = "0.15.21"

    [deps.Latexify.extensions]
    DataFramesExt = "DataFrames"
    DiffEqBiologicalExt = "DiffEqBiological"
    ParameterizedFunctionsExt = "DiffEqBase"
    SymEngineExt = "SymEngine"

    [deps.Latexify.weakdeps]
    DataFrames = "a93c6f00-e57d-5684-b7b6-d8193f3e46c0"
    DiffEqBase = "2b5f629d-d688-5b77-993f-72d75c75574e"
    DiffEqBiological = "eb300fae-53e8-50a0-950c-e21f52c2b7e0"
    SymEngine = "123dc426-2d89-5057-bbad-38513e3affd8"

[[deps.LibCURL]]
deps = ["LibCURL_jll", "MozillaCACerts_jll"]
uuid = "b27032c2-a3e7-50c8-80cd-2d36dbcbfd21"
version = "0.6.4"

[[deps.LibCURL_jll]]
deps = ["Artifacts", "LibSSH2_jll", "Libdl", "MbedTLS_jll", "Zlib_jll", "nghttp2_jll"]
uuid = "deac9b47-8bc7-5906-a0fe-35ac56dc84c0"
version = "8.6.0+0"

[[deps.LibGit2]]
deps = ["Base64", "LibGit2_jll", "NetworkOptions", "Printf", "SHA"]
uuid = "76f85450-5226-5b5a-8eaa-529ad045b433"
version = "1.11.0"

[[deps.LibGit2_jll]]
deps = ["Artifacts", "LibSSH2_jll", "Libdl", "MbedTLS_jll"]
uuid = "e37daf67-58a4-590a-8e99-b0245dd2ffc5"
version = "1.7.2+0"

[[deps.LibSSH2_jll]]
deps = ["Artifacts", "Libdl", "MbedTLS_jll"]
uuid = "29816b5a-b9ab-546f-933c-edad1886dfa8"
version = "1.11.0+1"

[[deps.Libdl]]
uuid = "8f399da3-3557-5675-b5ff-fb832c97cbdb"
version = "1.11.0"

[[deps.Libffi_jll]]
deps = ["Artifacts", "JLLWrappers", "Libdl", "Pkg"]
git-tree-sha1 = "27ecae93dd25ee0909666e6835051dd684cc035e"
uuid = "e9f186c6-92d2-5b65-8a66-fee21dc1b490"
version = "3.2.2+2"

[[deps.Libgcrypt_jll]]
deps = ["Artifacts", "JLLWrappers", "Libdl", "Libgpg_error_jll"]
git-tree-sha1 = "8be878062e0ffa2c3f67bb58a595375eda5de80b"
uuid = "d4300ac3-e22c-5743-9152-c294e39db1e4"
version = "1.11.0+0"

[[deps.Libglvnd_jll]]
deps = ["Artifacts", "JLLWrappers", "Libdl", "Xorg_libX11_jll", "Xorg_libXext_jll"]
git-tree-sha1 = "ff3b4b9d35de638936a525ecd36e86a8bb919d11"
uuid = "7e76a0d4-f3c7-5321-8279-8d96eeed0f29"
version = "1.7.0+0"

[[deps.Libgpg_error_jll]]
deps = ["Artifacts", "JLLWrappers", "Libdl"]
git-tree-sha1 = "df37206100d39f79b3376afb6b9cee4970041c61"
uuid = "7add5ba3-2f88-524e-9cd5-f83b8a55f7b8"
version = "1.51.1+0"

[[deps.Libiconv_jll]]
deps = ["Artifacts", "JLLWrappers", "Libdl"]
git-tree-sha1 = "be484f5c92fad0bd8acfef35fe017900b0b73809"
uuid = "94ce4f54-9a6c-5748-9c1c-f9c7231a4531"
version = "1.18.0+0"

[[deps.Libmount_jll]]
deps = ["Artifacts", "JLLWrappers", "Libdl"]
git-tree-sha1 = "89211ea35d9df5831fca5d33552c02bd33878419"
uuid = "4b2f31a3-9ecc-558c-b454-b3730dcb73e9"
version = "2.40.3+0"

[[deps.Libtiff_jll]]
deps = ["Artifacts", "JLLWrappers", "JpegTurbo_jll", "LERC_jll", "Libdl", "Pkg", "Zlib_jll", "Zstd_jll"]
git-tree-sha1 = "3eb79b0ca5764d4799c06699573fd8f533259713"
uuid = "89763e89-9b03-5906-acba-b20f662cd828"
version = "4.4.0+0"

[[deps.Libuuid_jll]]
deps = ["Artifacts", "JLLWrappers", "Libdl"]
git-tree-sha1 = "e888ad02ce716b319e6bdb985d2ef300e7089889"
uuid = "38a345b3-de98-5d2b-a5d3-14cd9215e700"
version = "2.40.3+0"

[[deps.LinearAlgebra]]
deps = ["Libdl", "OpenBLAS_jll", "libblastrampoline_jll"]
uuid = "37e2e46d-f89d-539d-b4ee-838fcccc9c8e"
version = "1.11.0"

[[deps.LogExpFunctions]]
deps = ["DocStringExtensions", "IrrationalConstants", "LinearAlgebra"]
git-tree-sha1 = "13ca9e2586b89836fd20cccf56e57e2b9ae7f38f"
uuid = "2ab3a3ac-af41-5b50-aa03-7779005ae688"
version = "0.3.29"

    [deps.LogExpFunctions.extensions]
    LogExpFunctionsChainRulesCoreExt = "ChainRulesCore"
    LogExpFunctionsChangesOfVariablesExt = "ChangesOfVariables"
    LogExpFunctionsInverseFunctionsExt = "InverseFunctions"

    [deps.LogExpFunctions.weakdeps]
    ChainRulesCore = "d360d2e6-b24c-11e9-a2a3-2a2ae2dbcce4"
    ChangesOfVariables = "9e997f8a-9a97-42d5-a9f1-ce6bfc15e2c0"
    InverseFunctions = "3587e190-3f89-42d0-90ee-14403ec27112"

[[deps.Logging]]
uuid = "56ddb016-857b-54e1-b83d-db4d58db5568"
version = "1.11.0"

[[deps.MacroTools]]
git-tree-sha1 = "72aebe0b5051e5143a079a4685a46da330a40472"
uuid = "1914dd2f-81c6-5fcd-8719-6d5c9610ff09"
version = "0.5.15"

[[deps.Markdown]]
deps = ["Base64"]
uuid = "d6f4376e-aef5-505a-96c1-9c027394607a"
version = "1.11.0"

[[deps.MbedTLS]]
deps = ["Dates", "MbedTLS_jll", "MozillaCACerts_jll", "NetworkOptions", "Random", "Sockets"]
git-tree-sha1 = "c067a280ddc25f196b5e7df3877c6b226d390aaf"
uuid = "739be429-bea8-5141-9913-cc70e7f3736d"
version = "1.1.9"

[[deps.MbedTLS_jll]]
deps = ["Artifacts", "Libdl"]
uuid = "c8ffd9c3-330d-5841-b78e-0817d7145fa1"
version = "2.28.6+0"

[[deps.Measures]]
git-tree-sha1 = "c13304c81eec1ed3af7fc20e75fb6b26092a1102"
uuid = "442fdcdd-2543-5da2-b0f3-8c86c306513e"
version = "0.3.2"

[[deps.Missings]]
deps = ["DataAPI"]
git-tree-sha1 = "ec4f7fbeab05d7747bdf98eb74d130a2a2ed298d"
uuid = "e1d29d7a-bbdc-5cf2-9ac0-f12de2c33e28"
version = "1.2.0"

[[deps.Mmap]]
uuid = "a63ad114-7e13-5084-954f-fe012c677804"
version = "1.11.0"

[[deps.MozillaCACerts_jll]]
uuid = "14a3606d-f60d-562e-9121-12d972cd8159"
version = "2023.12.12"

[[deps.NaNMath]]
deps = ["OpenLibm_jll"]
git-tree-sha1 = "fe891aea7ccd23897520db7f16931212454e277e"
uuid = "77ba4419-2d1f-58cd-9bb1-8ffee604a2e3"
version = "1.1.1"

[[deps.NetworkOptions]]
uuid = "ca575930-c2e3-43a9-ace4-1e988b2c1908"
version = "1.2.0"

[[deps.Ogg_jll]]
deps = ["Artifacts", "JLLWrappers", "Libdl", "Pkg"]
git-tree-sha1 = "887579a3eb005446d514ab7aeac5d1d027658b8f"
uuid = "e7412a2a-1a6e-54c0-be00-318e2571c051"
version = "1.3.5+1"

[[deps.OpenBLAS_jll]]
deps = ["Artifacts", "CompilerSupportLibraries_jll", "Libdl"]
uuid = "4536629a-c528-5b80-bd46-f80d51c5b363"
version = "0.3.27+1"

[[deps.OpenLibm_jll]]
deps = ["Artifacts", "Libdl"]
uuid = "05823500-19ac-5b8b-9628-191a04bc5112"
version = "0.8.1+2"

[[deps.OpenSSL_jll]]
deps = ["Artifacts", "JLLWrappers", "Libdl"]
git-tree-sha1 = "ad31332567b189f508a3ea8957a2640b1147ab00"
uuid = "458c3c95-2e84-50aa-8efc-19380b2a3a95"
version = "1.1.23+1"

[[deps.Opus_jll]]
deps = ["Artifacts", "JLLWrappers", "Libdl"]
git-tree-sha1 = "6703a85cb3781bd5909d48730a67205f3f31a575"
uuid = "91d4177d-7536-5919-b921-800302f37372"
version = "1.3.3+0"

[[deps.OrderedCollections]]
git-tree-sha1 = "12f1439c4f986bb868acda6ea33ebc78e19b95ad"
uuid = "bac558e1-5e72-5ebc-8fee-abe8a469f55d"
version = "1.7.0"

[[deps.PCRE2_jll]]
deps = ["Artifacts", "Libdl"]
uuid = "efcefdf7-47ab-520b-bdef-62a2eaa19f15"
version = "10.42.0+1"

[[deps.Pango_jll]]
deps = ["Artifacts", "Cairo_jll", "Fontconfig_jll", "FreeType2_jll", "FriBidi_jll", "Glib_jll", "HarfBuzz_jll", "JLLWrappers", "Libdl"]
git-tree-sha1 = "ed6834e95bd326c52d5675b4181386dfbe885afb"
uuid = "36c8627f-9965-5494-a995-c6b170f724f3"
version = "1.55.5+0"

[[deps.Parsers]]
deps = ["Dates", "PrecompileTools", "UUIDs"]
git-tree-sha1 = "8489905bcdbcfac64d1daa51ca07c0d8f0283821"
uuid = "69de0a69-1ddd-5017-9359-2bf0b02dc9f0"
version = "2.8.1"

[[deps.Pixman_jll]]
deps = ["Artifacts", "CompilerSupportLibraries_jll", "JLLWrappers", "LLVMOpenMP_jll", "Libdl"]
git-tree-sha1 = "35621f10a7531bc8fa58f74610b1bfb70a3cfc6b"
uuid = "30392449-352a-5448-841d-b1acce4e97dc"
version = "0.43.4+0"

[[deps.Pkg]]
deps = ["Artifacts", "Dates", "Downloads", "FileWatching", "LibGit2", "Libdl", "Logging", "Markdown", "Printf", "Random", "SHA", "TOML", "Tar", "UUIDs", "p7zip_jll"]
uuid = "44cfe95a-1eb2-52ea-b672-e2afdf69b78f"
version = "1.11.0"
weakdeps = ["REPL"]

    [deps.Pkg.extensions]
    REPLExt = "REPL"

[[deps.PlotThemes]]
deps = ["PlotUtils", "Requires", "Statistics"]
git-tree-sha1 = "a3a964ce9dc7898193536002a6dd892b1b5a6f1d"
uuid = "ccf2f8ad-2431-5c83-bf29-c5338b663b6a"
version = "2.0.1"

[[deps.PlotUtils]]
deps = ["ColorSchemes", "Colors", "Dates", "PrecompileTools", "Printf", "Random", "Reexport", "StableRNGs", "Statistics"]
git-tree-sha1 = "3ca9a356cd2e113c420f2c13bea19f8d3fb1cb18"
uuid = "995b91a9-d308-5afd-9ec6-746e21dbc043"
version = "1.4.3"

[[deps.Plots]]
deps = ["Base64", "Contour", "Dates", "Downloads", "FFMPEG", "FixedPointNumbers", "GR", "GeometryBasics", "JSON", "Latexify", "LinearAlgebra", "Measures", "NaNMath", "PlotThemes", "PlotUtils", "Printf", "REPL", "Random", "RecipesBase", "RecipesPipeline", "Reexport", "Requires", "Scratch", "Showoff", "SparseArrays", "Statistics", "StatsBase", "UUIDs", "UnicodeFun", "Unzip"]
git-tree-sha1 = "d16070abde61120e01b4f30f6f398496582301d6"
uuid = "91a5bcdd-55d7-5caf-9e0b-520d859cae80"
version = "1.25.12"

[[deps.PrecompileTools]]
deps = ["Preferences"]
git-tree-sha1 = "5aa36f7049a63a1528fe8f7c3f2113413ffd4e1f"
uuid = "aea7be01-6a6a-4083-8856-8a6e6704d82a"
version = "1.2.1"

[[deps.Preferences]]
deps = ["TOML"]
git-tree-sha1 = "9306f6085165d270f7e3db02af26a400d580f5c6"
uuid = "21216c6a-2e73-6563-6e65-726566657250"
version = "1.4.3"

[[deps.Printf]]
deps = ["Unicode"]
uuid = "de0858da-6303-5e67-8744-51eddeeeb8d7"
version = "1.11.0"

[[deps.Profile]]
uuid = "9abbd945-dff8-562f-b5e8-e1ebf5ef1b79"
version = "1.11.0"

[[deps.Qt5Base_jll]]
deps = ["Artifacts", "CompilerSupportLibraries_jll", "Fontconfig_jll", "Glib_jll", "JLLWrappers", "Libdl", "Libglvnd_jll", "OpenSSL_jll", "Pkg", "Xorg_libXext_jll", "Xorg_libxcb_jll", "Xorg_xcb_util_image_jll", "Xorg_xcb_util_keysyms_jll", "Xorg_xcb_util_renderutil_jll", "Xorg_xcb_util_wm_jll", "Zlib_jll", "xkbcommon_jll"]
git-tree-sha1 = "0c03844e2231e12fda4d0086fd7cbe4098ee8dc5"
uuid = "ea2cea3b-5b76-57ae-a6ef-0a8af62496e1"
version = "5.15.3+2"

[[deps.REPL]]
deps = ["InteractiveUtils", "Markdown", "Sockets", "StyledStrings", "Unicode"]
uuid = "3fa0cd96-eef1-5676-8a61-b3b8758bbffb"
version = "1.11.0"

[[deps.Random]]
deps = ["SHA"]
uuid = "9a3f8284-a2c9-5f02-9a11-845980a1fd5c"
version = "1.11.0"

[[deps.RecipesBase]]
deps = ["PrecompileTools"]
git-tree-sha1 = "5c3d09cc4f31f5fc6af001c250bf1278733100ff"
uuid = "3cdcf5f2-1ef4-517c-9805-6587b60abb01"
version = "1.3.4"

[[deps.RecipesPipeline]]
deps = ["Dates", "NaNMath", "PlotUtils", "RecipesBase"]
git-tree-sha1 = "dc1e451e15d90347a7decc4221842a022b011714"
uuid = "01d81517-befc-4cb6-b9ec-a95719d0359c"
version = "0.5.2"

[[deps.Reexport]]
git-tree-sha1 = "45e428421666073eab6f2da5c9d310d99bb12f9b"
uuid = "189a3867-3050-52da-a836-e630ba90ab69"
version = "1.2.2"

[[deps.RelocatableFolders]]
deps = ["SHA", "Scratch"]
git-tree-sha1 = "cdbd3b1338c72ce29d9584fdbe9e9b70eeb5adca"
uuid = "05181044-ff0b-4ac5-8273-598c1e38db00"
version = "0.1.3"

[[deps.Requires]]
deps = ["UUIDs"]
git-tree-sha1 = "838a3a4188e2ded87a4f9f184b4b0d78a1e91cb7"
uuid = "ae029012-a4dd-5104-9daa-d747884805df"
version = "1.3.0"

[[deps.SHA]]
uuid = "ea8e919c-243c-51af-8825-aaa63cd721ce"
version = "0.7.0"

[[deps.Scratch]]
deps = ["Dates"]
git-tree-sha1 = "3bac05bc7e74a75fd9cba4295cde4045d9fe2386"
uuid = "6c6a2e73-6563-6170-7368-637461726353"
version = "1.2.1"

[[deps.Serialization]]
uuid = "9e88b42a-f829-5b0c-bbe9-9e923198166b"
version = "1.11.0"

[[deps.Showoff]]
deps = ["Dates", "Grisu"]
git-tree-sha1 = "91eddf657aca81df9ae6ceb20b959ae5653ad1de"
uuid = "992d4aef-0814-514b-bc4d-f2e9a6c4116f"
version = "1.0.3"

[[deps.Sockets]]
uuid = "6462fe0b-24de-5631-8697-dd941f90decc"
version = "1.11.0"

[[deps.SortingAlgorithms]]
deps = ["DataStructures"]
git-tree-sha1 = "66e0a8e672a0bdfca2c3f5937efb8538b9ddc085"
uuid = "a2af1166-a08f-5f64-846c-94a0d3cef48c"
version = "1.2.1"

[[deps.SparseArrays]]
deps = ["Libdl", "LinearAlgebra", "Random", "Serialization", "SuiteSparse_jll"]
uuid = "2f01184e-e22b-5df5-ae63-d93ebab69eaf"
version = "1.11.0"

[[deps.StableRNGs]]
deps = ["Random"]
git-tree-sha1 = "83e6cce8324d49dfaf9ef059227f91ed4441a8e5"
uuid = "860ef19b-820b-49d6-a774-d7a799459cd3"
version = "1.0.2"

[[deps.StaticArrays]]
deps = ["LinearAlgebra", "PrecompileTools", "Random", "StaticArraysCore"]
git-tree-sha1 = "02c8bd479d26dbeff8a7eb1d77edfc10dacabc01"
uuid = "90137ffa-7385-5640-81b9-e52037218182"
version = "1.9.11"

    [deps.StaticArrays.extensions]
    StaticArraysChainRulesCoreExt = "ChainRulesCore"
    StaticArraysStatisticsExt = "Statistics"

    [deps.StaticArrays.weakdeps]
    ChainRulesCore = "d360d2e6-b24c-11e9-a2a3-2a2ae2dbcce4"
    Statistics = "10745b16-79ce-11e8-11f9-7d13ad32a3b2"

[[deps.StaticArraysCore]]
git-tree-sha1 = "192954ef1208c7019899fbf8049e717f92959682"
uuid = "1e83bf80-4336-4d27-bf5d-d5a4f845583c"
version = "1.4.3"

[[deps.Statistics]]
deps = ["LinearAlgebra"]
git-tree-sha1 = "ae3bb1eb3bba077cd276bc5cfc337cc65c3075c0"
uuid = "10745b16-79ce-11e8-11f9-7d13ad32a3b2"
version = "1.11.1"
weakdeps = ["SparseArrays"]

    [deps.Statistics.extensions]
    SparseArraysExt = ["SparseArrays"]

[[deps.StatsAPI]]
deps = ["LinearAlgebra"]
git-tree-sha1 = "1ff449ad350c9c4cbc756624d6f8a8c3ef56d3ed"
uuid = "82ae8749-77ed-4fe6-ae5f-f523153014b0"
version = "1.7.0"

[[deps.StatsBase]]
deps = ["DataAPI", "DataStructures", "LinearAlgebra", "LogExpFunctions", "Missings", "Printf", "Random", "SortingAlgorithms", "SparseArrays", "Statistics", "StatsAPI"]
git-tree-sha1 = "d1bf48bfcc554a3761a133fe3a9bb01488e06916"
uuid = "2913bbd2-ae8a-5f71-8c99-4fb6c76f3a91"
version = "0.33.21"

[[deps.StructArrays]]
deps = ["ConstructionBase", "DataAPI", "Tables"]
git-tree-sha1 = "9537ef82c42cdd8c5d443cbc359110cbb36bae10"
uuid = "09ab397b-f2b6-538f-b94a-2f83cf4a842a"
version = "0.6.21"

    [deps.StructArrays.extensions]
    StructArraysAdaptExt = "Adapt"
    StructArraysGPUArraysCoreExt = ["GPUArraysCore", "KernelAbstractions"]
    StructArraysLinearAlgebraExt = "LinearAlgebra"
    StructArraysSparseArraysExt = "SparseArrays"
    StructArraysStaticArraysExt = "StaticArrays"

    [deps.StructArrays.weakdeps]
    Adapt = "79e6a3ab-5dfb-504d-930d-738a2a938a0e"
    GPUArraysCore = "46192b85-c4d5-4398-a991-12ede77f4527"
    KernelAbstractions = "63c18a36-062a-441e-b654-da1e3ab1ce7c"
    LinearAlgebra = "37e2e46d-f89d-539d-b4ee-838fcccc9c8e"
    SparseArrays = "2f01184e-e22b-5df5-ae63-d93ebab69eaf"
    StaticArrays = "90137ffa-7385-5640-81b9-e52037218182"

[[deps.StyledStrings]]
uuid = "f489334b-da3d-4c2e-b8f0-e476e12c162b"
version = "1.11.0"

[[deps.SuiteSparse_jll]]
deps = ["Artifacts", "Libdl", "libblastrampoline_jll"]
uuid = "bea87d4a-7f5b-5778-9afe-8cc45184846c"
version = "7.7.0+0"

[[deps.TOML]]
deps = ["Dates"]
uuid = "fa267f1f-6049-4f14-aa54-33bafae1ed76"
version = "1.0.3"

[[deps.TableTraits]]
deps = ["IteratorInterfaceExtensions"]
git-tree-sha1 = "c06b2f539df1c6efa794486abfb6ed2022561a39"
uuid = "3783bdb8-4a98-5b6b-af9a-565f29a5fe9c"
version = "1.0.1"

[[deps.Tables]]
deps = ["DataAPI", "DataValueInterfaces", "IteratorInterfaceExtensions", "OrderedCollections", "TableTraits"]
git-tree-sha1 = "598cd7c1f68d1e205689b1c2fe65a9f85846f297"
uuid = "bd369af6-aec1-5ad0-b16a-f7cc5008161c"
version = "1.12.0"

[[deps.Tar]]
deps = ["ArgTools", "SHA"]
uuid = "a4e569a6-e804-4fa4-b0f3-eef7a1d5b13e"
version = "1.10.0"

[[deps.TensorCore]]
deps = ["LinearAlgebra"]
git-tree-sha1 = "1feb45f88d133a655e001435632f019a9a1bcdb6"
uuid = "62fd8b95-f654-4bbd-a8a5-9c27f68ccd50"
version = "0.1.1"

[[deps.Test]]
deps = ["InteractiveUtils", "Logging", "Random", "Serialization"]
uuid = "8dfed614-e22c-5e08-85e1-65c5234f0b40"
version = "1.11.0"

[[deps.URIs]]
git-tree-sha1 = "67db6cc7b3821e19ebe75791a9dd19c9b1188f2b"
uuid = "5c2747f8-b7ea-4ff2-ba2e-563bfd36b1d4"
version = "1.5.1"

[[deps.UUIDs]]
deps = ["Random", "SHA"]
uuid = "cf7118a7-6976-5b1a-9a39-7adc72f591a4"
version = "1.11.0"

[[deps.Unicode]]
uuid = "4ec0a83e-493e-50e2-b9ac-8f72acf5a8f5"
version = "1.11.0"

[[deps.UnicodeFun]]
deps = ["REPL"]
git-tree-sha1 = "53915e50200959667e78a92a418594b428dffddf"
uuid = "1cfade01-22cf-5700-b092-accc4b62d6e1"
version = "0.4.1"

[[deps.Unzip]]
git-tree-sha1 = "34db80951901073501137bdbc3d5a8e7bbd06670"
uuid = "41fe7b60-77ed-43a1-b4f0-825fd5a5650d"
version = "0.1.2"

[[deps.Wayland_jll]]
deps = ["Artifacts", "EpollShim_jll", "Expat_jll", "JLLWrappers", "Libdl", "Libffi_jll", "Pkg", "XML2_jll"]
git-tree-sha1 = "85c7811eddec9e7f22615371c3cc81a504c508ee"
uuid = "a2964d1f-97da-50d4-b82a-358c7fce9d89"
version = "1.21.0+2"

[[deps.Wayland_protocols_jll]]
deps = ["Artifacts", "JLLWrappers", "Libdl", "Pkg"]
git-tree-sha1 = "5db3e9d307d32baba7067b13fc7b5aa6edd4a19a"
uuid = "2381bf8a-dfd0-557d-9999-79630e7b1b91"
version = "1.36.0+0"

[[deps.XML2_jll]]
deps = ["Artifacts", "JLLWrappers", "Libdl", "Libiconv_jll", "Zlib_jll"]
git-tree-sha1 = "a2fccc6559132927d4c5dc183e3e01048c6dcbd6"
uuid = "02c8fc9c-b97f-50b9-bbe4-9be30ff0a78a"
version = "2.13.5+0"

[[deps.XSLT_jll]]
deps = ["Artifacts", "JLLWrappers", "Libdl", "Libgcrypt_jll", "Libgpg_error_jll", "Libiconv_jll", "XML2_jll", "Zlib_jll"]
git-tree-sha1 = "7d1671acbe47ac88e981868a078bd6b4e27c5191"
uuid = "aed1982a-8fda-507f-9586-7b0439959a61"
version = "1.1.42+0"

[[deps.Xorg_libX11_jll]]
deps = ["Artifacts", "JLLWrappers", "Libdl", "Xorg_libxcb_jll", "Xorg_xtrans_jll"]
git-tree-sha1 = "9dafcee1d24c4f024e7edc92603cedba72118283"
uuid = "4f6342f7-b3d2-589e-9d20-edeb45f2b2bc"
version = "1.8.6+3"

[[deps.Xorg_libXau_jll]]
deps = ["Artifacts", "JLLWrappers", "Libdl"]
git-tree-sha1 = "e9216fdcd8514b7072b43653874fd688e4c6c003"
uuid = "0c0b7dd1-d40b-584c-a123-a41640f87eec"
version = "1.0.12+0"

[[deps.Xorg_libXcursor_jll]]
deps = ["Artifacts", "JLLWrappers", "Libdl", "Xorg_libXfixes_jll", "Xorg_libXrender_jll"]
git-tree-sha1 = "807c226eaf3651e7b2c468f687ac788291f9a89b"
uuid = "935fb764-8cf2-53bf-bb30-45bb1f8bf724"
version = "1.2.3+0"

[[deps.Xorg_libXdmcp_jll]]
deps = ["Artifacts", "JLLWrappers", "Libdl"]
git-tree-sha1 = "89799ae67c17caa5b3b5a19b8469eeee474377db"
uuid = "a3789734-cfe1-5b06-b2d0-1dd0d9d62d05"
version = "1.1.5+0"

[[deps.Xorg_libXext_jll]]
deps = ["Artifacts", "JLLWrappers", "Libdl", "Xorg_libX11_jll"]
git-tree-sha1 = "d7155fea91a4123ef59f42c4afb5ab3b4ca95058"
uuid = "1082639a-0dae-5f34-9b06-72781eeb8cb3"
version = "1.3.6+3"

[[deps.Xorg_libXfixes_jll]]
deps = ["Artifacts", "JLLWrappers", "Libdl", "Xorg_libX11_jll"]
git-tree-sha1 = "6fcc21d5aea1a0b7cce6cab3e62246abd1949b86"
uuid = "d091e8ba-531a-589c-9de9-94069b037ed8"
version = "6.0.0+0"

[[deps.Xorg_libXi_jll]]
deps = ["Artifacts", "JLLWrappers", "Libdl", "Xorg_libXext_jll", "Xorg_libXfixes_jll"]
git-tree-sha1 = "984b313b049c89739075b8e2a94407076de17449"
uuid = "a51aa0fd-4e3c-5386-b890-e753decda492"
version = "1.8.2+0"

[[deps.Xorg_libXinerama_jll]]
deps = ["Artifacts", "JLLWrappers", "Libdl", "Xorg_libXext_jll"]
git-tree-sha1 = "a1a7eaf6c3b5b05cb903e35e8372049b107ac729"
uuid = "d1454406-59df-5ea1-beac-c340f2130bc3"
version = "1.1.5+0"

[[deps.Xorg_libXrandr_jll]]
deps = ["Artifacts", "JLLWrappers", "Libdl", "Xorg_libXext_jll", "Xorg_libXrender_jll"]
git-tree-sha1 = "b6f664b7b2f6a39689d822a6300b14df4668f0f4"
uuid = "ec84b674-ba8e-5d96-8ba1-2a689ba10484"
version = "1.5.4+0"

[[deps.Xorg_libXrender_jll]]
deps = ["Artifacts", "JLLWrappers", "Libdl", "Xorg_libX11_jll"]
git-tree-sha1 = "a490c6212a0e90d2d55111ac956f7c4fa9c277a6"
uuid = "ea2f1a96-1ddc-540d-b46f-429655e07cfa"
version = "0.9.11+1"

[[deps.Xorg_libpthread_stubs_jll]]
deps = ["Artifacts", "JLLWrappers", "Libdl"]
git-tree-sha1 = "c57201109a9e4c0585b208bb408bc41d205ac4e9"
uuid = "14d82f49-176c-5ed1-bb49-ad3f5cbd8c74"
version = "0.1.2+0"

[[deps.Xorg_libxcb_jll]]
deps = ["Artifacts", "JLLWrappers", "Libdl", "XSLT_jll", "Xorg_libXau_jll", "Xorg_libXdmcp_jll", "Xorg_libpthread_stubs_jll"]
git-tree-sha1 = "1a74296303b6524a0472a8cb12d3d87a78eb3612"
uuid = "c7cfdc94-dc32-55de-ac96-5a1b8d977c5b"
version = "1.17.0+3"

[[deps.Xorg_libxkbfile_jll]]
deps = ["Artifacts", "JLLWrappers", "Libdl", "Xorg_libX11_jll"]
git-tree-sha1 = "dbc53e4cf7701c6c7047c51e17d6e64df55dca94"
uuid = "cc61e674-0454-545c-8b26-ed2c68acab7a"
version = "1.1.2+1"

[[deps.Xorg_xcb_util_image_jll]]
deps = ["Artifacts", "JLLWrappers", "Libdl", "Pkg", "Xorg_xcb_util_jll"]
git-tree-sha1 = "0fab0a40349ba1cba2c1da699243396ff8e94b97"
uuid = "12413925-8142-5f55-bb0e-6d7ca50bb09b"
version = "0.4.0+1"

[[deps.Xorg_xcb_util_jll]]
deps = ["Artifacts", "JLLWrappers", "Libdl", "Pkg", "Xorg_libxcb_jll"]
git-tree-sha1 = "e7fd7b2881fa2eaa72717420894d3938177862d1"
uuid = "2def613f-5ad1-5310-b15b-b15d46f528f5"
version = "0.4.0+1"

[[deps.Xorg_xcb_util_keysyms_jll]]
deps = ["Artifacts", "JLLWrappers", "Libdl", "Pkg", "Xorg_xcb_util_jll"]
git-tree-sha1 = "d1151e2c45a544f32441a567d1690e701ec89b00"
uuid = "975044d2-76e6-5fbe-bf08-97ce7c6574c7"
version = "0.4.0+1"

[[deps.Xorg_xcb_util_renderutil_jll]]
deps = ["Artifacts", "JLLWrappers", "Libdl", "Pkg", "Xorg_xcb_util_jll"]
git-tree-sha1 = "dfd7a8f38d4613b6a575253b3174dd991ca6183e"
uuid = "0d47668e-0667-5a69-a72c-f761630bfb7e"
version = "0.3.9+1"

[[deps.Xorg_xcb_util_wm_jll]]
deps = ["Artifacts", "JLLWrappers", "Libdl", "Pkg", "Xorg_xcb_util_jll"]
git-tree-sha1 = "e78d10aab01a4a154142c5006ed44fd9e8e31b67"
uuid = "c22f9ab0-d5fe-5066-847c-f4bb1cd4e361"
version = "0.4.1+1"

[[deps.Xorg_xkbcomp_jll]]
deps = ["Artifacts", "JLLWrappers", "Libdl", "Xorg_libxkbfile_jll"]
git-tree-sha1 = "ab2221d309eda71020cdda67a973aa582aa85d69"
uuid = "35661453-b289-5fab-8a00-3d9160c6a3a4"
version = "1.4.6+1"

[[deps.Xorg_xkeyboard_config_jll]]
deps = ["Artifacts", "JLLWrappers", "Libdl", "Xorg_xkbcomp_jll"]
git-tree-sha1 = "691634e5453ad362044e2ad653e79f3ee3bb98c3"
uuid = "33bec58e-1273-512f-9401-5d533626f822"
version = "2.39.0+0"

[[deps.Xorg_xtrans_jll]]
deps = ["Artifacts", "JLLWrappers", "Libdl"]
git-tree-sha1 = "6dba04dbfb72ae3ebe5418ba33d087ba8aa8cb00"
uuid = "c5fb5394-a638-5e4d-96e5-b29de1b5cf10"
version = "1.5.1+0"

[[deps.Zlib_jll]]
deps = ["Libdl"]
uuid = "83775a58-1f1d-513f-b197-d71354ab007a"
version = "1.2.13+1"

[[deps.Zstd_jll]]
deps = ["Artifacts", "JLLWrappers", "Libdl"]
git-tree-sha1 = "622cf78670d067c738667aaa96c553430b65e269"
uuid = "3161d3a3-bdf6-5164-811a-617609db77b4"
version = "1.5.7+0"

[[deps.libaom_jll]]
deps = ["Artifacts", "JLLWrappers", "Libdl"]
git-tree-sha1 = "522c1df09d05a71785765d19c9524661234738e9"
uuid = "a4ae2306-e953-59d6-aa16-d00cac43593b"
version = "3.11.0+0"

[[deps.libass_jll]]
deps = ["Artifacts", "Bzip2_jll", "FreeType2_jll", "FriBidi_jll", "HarfBuzz_jll", "JLLWrappers", "Libdl", "Zlib_jll"]
git-tree-sha1 = "e17c115d55c5fbb7e52ebedb427a0dca79d4484e"
uuid = "0ac62f75-1d6f-5e53-bd7c-93b484bb37c0"
version = "0.15.2+0"

[[deps.libblastrampoline_jll]]
deps = ["Artifacts", "Libdl"]
uuid = "8e850b90-86db-534c-a0d3-1478176c7d93"
version = "5.11.0+0"

[[deps.libdecor_jll]]
deps = ["Artifacts", "Dbus_jll", "JLLWrappers", "Libdl", "Libglvnd_jll", "Pango_jll", "Wayland_jll", "xkbcommon_jll"]
git-tree-sha1 = "9bf7903af251d2050b467f76bdbe57ce541f7f4f"
uuid = "1183f4f0-6f2a-5f1a-908b-139f9cdfea6f"
version = "0.2.2+0"

[[deps.libfdk_aac_jll]]
deps = ["Artifacts", "JLLWrappers", "Libdl"]
git-tree-sha1 = "8a22cf860a7d27e4f3498a0fe0811a7957badb38"
uuid = "f638f0a6-7fb0-5443-88ba-1cc74229b280"
version = "2.0.3+0"

[[deps.libpng_jll]]
deps = ["Artifacts", "JLLWrappers", "Libdl", "Zlib_jll"]
git-tree-sha1 = "055a96774f383318750a1a5e10fd4151f04c29c5"
uuid = "b53b4c65-9356-5827-b1ea-8c7a1a84506f"
version = "1.6.46+0"

[[deps.libvorbis_jll]]
deps = ["Artifacts", "JLLWrappers", "Libdl", "Ogg_jll", "Pkg"]
git-tree-sha1 = "490376214c4721cdaca654041f635213c6165cb3"
uuid = "f27f6e37-5d2b-51aa-960f-b287f2bc3b7a"
version = "1.3.7+2"

[[deps.nghttp2_jll]]
deps = ["Artifacts", "Libdl"]
uuid = "8e850ede-7688-5339-a07c-302acd2aaf8d"
version = "1.59.0+0"

[[deps.p7zip_jll]]
deps = ["Artifacts", "Libdl"]
uuid = "3f19e933-33d8-53b3-aaab-bd5110c3b7a0"
version = "17.4.0+2"

[[deps.x264_jll]]
deps = ["Artifacts", "JLLWrappers", "Libdl", "Pkg"]
git-tree-sha1 = "4fea590b89e6ec504593146bf8b988b2c00922b2"
uuid = "1270edf5-f2f9-52d2-97e9-ab00b5d0237a"
version = "2021.5.5+0"

[[deps.x265_jll]]
deps = ["Artifacts", "JLLWrappers", "Libdl", "Pkg"]
git-tree-sha1 = "ee567a171cce03570d77ad3a43e90218e38937a9"
uuid = "dfaa095f-4041-5dcd-9319-2fabd8486b76"
version = "3.5.0+0"

[[deps.xkbcommon_jll]]
deps = ["Artifacts", "JLLWrappers", "Libdl", "Pkg", "Wayland_jll", "Wayland_protocols_jll", "Xorg_libxcb_jll", "Xorg_xkeyboard_config_jll"]
git-tree-sha1 = "63406453ed9b33a0df95d570816d5366c92b7809"
uuid = "d8fb68d0-12a3-5cfd-a85a-d49703b185fd"
version = "1.4.1+2"
"""

# ╔═╡ Cell order:
# ╟─e51b3be2-e244-11ef-3a7f-11713917530c
# ╠═7108b99c-357b-4385-8b6e-07d7e757d543
# ╠═2e4de51a-6342-4210-b10a-6a377c1e4cbf
# ╠═66e0c438-7737-4ed2-be6c-57e04b7d7dca
# ╟─ba1ce01d-4635-49f7-8a52-5a3a13371df0
# ╟─2caca4c0-7cbc-47cf-9de9-d2bb2bcb1026
# ╟─1a5a65cd-be68-4a4b-9f62-370ff6e944cb
# ╠═54efc026-9d48-46cf-857b-4b568f7b2351
# ╠═f0521e5d-5562-4ea7-95ff-d95a881a4674
# ╠═fd1e3751-fa08-474d-8e0a-8e3e8b6156d4
# ╠═6c26a87b-5fe3-4d77-aa11-8e2e99602134
# ╟─c8ac41bc-d3b5-48ce-827f-62343d60cc89
# ╟─5d36fbbb-355d-4715-b73b-589cb7d3e8c9
# ╟─aec2b89d-f9b4-412c-80b4-88f298c67da7
# ╠═2a88f6b2-efd6-4d86-8962-0e07e237b2cf
# ╠═f3381fe1-78fe-4bdc-b769-5e457eba1381
# ╠═9ac536fb-67aa-4e8d-99f5-f9541a0e7cfe
# ╠═ea7096ae-e6fe-4438-bd87-b974bb26a94d
# ╟─4c3b7291-40fe-41ba-9a95-eb8bba90f15f
# ╟─55a4c483-c491-4df0-81d1-c237312a434b
# ╟─9b37f0c6-d7f6-4b13-919e-3aedf9d6b727
# ╠═47b2bfc5-cee6-4fdc-9f46-955f734c13e4
# ╠═1e20168d-00df-4755-aec4-a3fe7cf542aa
# ╠═b8a9a54c-1a00-4793-a27e-e903663a2fa5
# ╠═a4862f08-62d2-4d34-b7e1-71f8cc01e50c
# ╟─f6e284b0-7a6a-4c63-a4b6-64ccec25bd48
# ╟─990bc37c-211f-4752-ae60-90af4ea5e17b
# ╠═252f8891-29e0-4f81-824f-2f980db51199
# ╠═7f37d06d-48f1-4d13-8aaa-2d3139a8ec71
# ╠═c21f610d-63e3-4ba2-b099-1b7552e57a0c
# ╠═48376322-4d91-4640-b555-1951b716184d
# ╟─22cc6ae1-1bc0-48ce-8353-b955b6beb737
# ╟─3185d2c0-7150-4a6d-aa23-b56174fb6cd3
# ╟─819dd2e0-6170-402c-9bec-58d2f0c74799
# ╠═1b5c73e0-db3e-4e8d-b27d-ac913cfe5711
# ╠═3de20394-e842-4f1a-bac6-a97183ed45ac
# ╠═4b2cf9d2-dfab-4508-bc8f-a57aa584d76e
# ╠═e8466e67-a177-46b6-979b-012a73d52eb1
# ╠═77e44a1c-34d9-44e8-97d8-8c744c147582
# ╠═a0f23dd8-004f-46f9-a2cd-2aa665586635
# ╟─e9f28824-c13c-4aac-981d-061b4d5571b1
# ╟─57cecc82-11ee-4129-a93e-a0ca946ae561
# ╟─937ec45b-5416-47ec-91dc-1784f5d91b79
# ╟─9ebdca25-0f08-446b-8216-b7a7ea3b5a77
# ╟─6ba1816b-4721-4ed5-8ebd-bd3266117309
# ╟─a301ee78-cef0-4b7b-87cf-6df6ee4d2b10
# ╟─2bc4374d-0da1-4c90-9e1c-d2fdcbe35b4d
# ╟─c175e2d1-84c7-41a5-be24-6deb59da761f
# ╟─139ae075-2a24-4051-a533-929b44796931
# ╟─57420368-0a8b-49ee-b9c6-2c27073ea047
# ╟─3afc1086-5f53-4891-acd3-b2e039f9a7fc
# ╟─2331344a-444f-4729-9e33-39381f3d65ef
# ╟─7cfd3185-98ac-454f-8c6b-10a19f56a9b0
# ╟─15878f2a-5052-47ee-af26-eaf6af363ced
# ╟─3cec9551-ae98-426d-9736-1229bf2a751b
# ╠═5890a0b9-46b1-43db-8b7c-c99d9b6125f1
# ╟─00000000-0000-0000-0000-000000000001
# ╟─00000000-0000-0000-0000-000000000002
